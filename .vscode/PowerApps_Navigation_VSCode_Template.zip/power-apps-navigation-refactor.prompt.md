---
mode: agent
description: Build or refactor reusable navigation for a Microsoft Power Apps Canvas App.
---

# Power Apps Navigation Refactor Prompt

You are working in a Microsoft Power Apps Canvas App project opened in VS Code.

## Goal

Refactor the app so navigation is centralized, reusable, easy to maintain, and suitable for future growth.

Do **not** invent screen names, role names, or data sources. First inspect the project and map the existing app structure. Then adapt the template below to the actual app.

## Required navigation architecture

Implement or recommend the following pattern:

1. A centralized navigation definition.
2. A reusable navigation component or shared menu pattern.
3. Explicit `Navigate()` calls for primary navigation.
4. `Back()` for true return/back behavior.
5. Screen context variables for passing selected records and view/edit modes.
6. Tabs/containers for multiple views of the same logical workspace instead of creating unnecessary screens.
7. `Param()` + `App.StartScreen` for deep-link support.
8. Role/permission filtering that controls which menu items are visible without mixing authorization logic into every button.
9. Avoid excessive global variables where screen context is sufficient.
10. Preserve all current app behavior unless a change is necessary for the new navigation pattern.

## Existing app placeholders

Replace these placeholders after inspecting the project:

- Home screen: `{{HOME_SCREEN}}`
- Primary screens:
  - `{{SCREEN_1}}`
  - `{{SCREEN_2}}`
  - `{{SCREEN_3}}`
  - `{{SCREEN_4}}`
- Detail screen: `{{DETAIL_SCREEN}}`
- Selected record variable/context name: `{{SELECTED_RECORD}}`
- Record ID field: `{{RECORD_ID_FIELD}}`
- Role collection/table: `{{ROLE_COLLECTION}}`
- Role field: `{{ROLE_FIELD}}`

## Target Power Fx patterns

### 1. Central navigation collection

Create the equivalent of this in `App.OnStart` or another appropriate initialization location:

```powerfx
ClearCollect(
    colNavigation,
    {Title: "Home", Target: {{HOME_SCREEN}}, RequiredRole: Blank()},
    {Title: "{{MENU_1}}", Target: {{SCREEN_1}}, RequiredRole: Blank()},
    {Title: "{{MENU_2}}", Target: {{SCREEN_2}}, RequiredRole: Blank()},
    {Title: "{{MENU_3}}", Target: {{SCREEN_3}}, RequiredRole: "{{ROLE_1}}"},
    {Title: "{{MENU_4}}", Target: {{SCREEN_4}}, RequiredRole: "{{ROLE_2}}"}
)
```

If the current app has icons or additional metadata, preserve them in this collection.

### 2. Reusable navigation control

For the gallery/menu item `OnSelect`:

```powerfx
Navigate(
    ThisItem.Target,
    ScreenTransition.None
)
```

For menu visibility/filtering, prefer a centralized expression such as:

```powerfx
Filter(
    colNavigation,
    IsBlank(RequiredRole) ||
    RequiredRole in {{ROLE_COLLECTION}}.{{ROLE_FIELD}}
)
```

Adapt this to the app's actual role/permission model.

### 3. Record-detail navigation

When opening a selected record, prefer screen context:

```powerfx
Navigate(
    {{DETAIL_SCREEN}},
    ScreenTransition.None,
    {
        ctxSelectedRecord: ThisItem,
        ctxMode: "View"
    }
)
```

For edit actions:

```powerfx
Navigate(
    {{DETAIL_SCREEN}},
    ScreenTransition.None,
    {
        ctxSelectedRecord: ThisItem,
        ctxMode: "Edit"
    }
)
```

Use the app's existing naming convention if one exists.

### 4. Back navigation

Use:

```powerfx
Back()
```

Do not hardcode a destination for a true Back button unless the existing workflow explicitly requires it.

### 5. Same-screen tabs

If several screens represent only different views of the same logical workspace, recommend consolidating them using a tab state variable:

```powerfx
Set(varSelectedTab, "Source")
```

Example container visibility:

```powerfx
varSelectedTab = "Source"
```

Other examples:

```powerfx
varSelectedTab = "Target"
```

```powerfx
varSelectedTab = "Differences"
```

Do not consolidate screens if doing so would break workflow, performance, accessibility, or delegation behavior.

### 6. Deep links

Support incoming links using `Param()`.

Example:

```powerfx
Param("recordId")
```

Use `App.StartScreen` to route a deep-linked user:

```powerfx
If(
    !IsBlank(Param("recordId")),
    {{DETAIL_SCREEN}},
    {{HOME_SCREEN}}
)
```

On the destination screen, retrieve the record safely using the actual data source and ID type. Do not assume whether the key is text, GUID, or numeric.

### 7. External navigation

Use `Launch()` for external URLs instead of `Navigate()`.

## Refactoring rules

- Do not duplicate navigation formulas unnecessarily.
- Do not create nested `If()` chains for role-based navigation when visibility/filtering can handle it centrally.
- Do not replace existing security with UI-only hiding.
- Preserve Dataverse/SharePoint/data-source permissions independently of UI visibility.
- Keep formulas delegation-safe where possible.
- Preserve existing component interfaces unless modification is required.
- Prefer existing app naming conventions.
- Do not rename screens or controls unless necessary.
- Do not remove working formulas without documenting the replacement.
- If a navigation formula currently performs additional business logic, preserve that logic and separate it cleanly from routing where possible.

## VS Code / Power Apps source warning

Before editing, determine how this project is connected to Power Apps.

Current Microsoft guidance distinguishes between:
- Power Platform Git Integration source, where supported source-control editing can be used.
- Generated `.pa.yaml` source viewed outside Git Integration, which may be read-only or regenerated.
- Older `pac canvas pack/unpack` workflows, which Microsoft now marks as deprecated/preview for source-control workflows.

Do not assume every `.pa.yaml` file should be edited directly.

## What I want you to do

1. Inspect the workspace.
2. Identify every screen and existing navigation formula.
3. Produce a navigation map:
   - source control/screen
   - trigger/control
   - current destination
   - variables/context passed
   - business logic performed
4. Identify duplicated or fragile navigation logic.
5. Propose the smallest safe refactor.
6. Implement the refactor only in files that are safe and intended to be edited.
7. Create or update a reusable navigation component/pattern.
8. Add deep-link handling if the app has a record-detail workflow.
9. Preserve existing functionality.
10. Report all modified files and explain each change.
11. Flag anything that still needs to be completed inside Power Apps Studio.

## Acceptance criteria

The result is complete when:

- Primary navigation is centralized.
- Repeated menu logic is removed.
- Back buttons use appropriate navigation history.
- Record navigation passes context cleanly.
- Same-workspace views use tabs/containers where appropriate.
- Deep links can route to a specific record or logical destination.
- Role-based menu visibility is centralized.
- Existing app security is not weakened.
- Existing workflows continue to function.
- All changes are documented.

## Optional project-specific navigation model

If this app is a source/target mapping or reconciliation app, prefer a navigation model similar to:

```text
Home / Dashboard
├── Projects
│   └── Project Detail
├── Mapping
│   ├── Source
│   ├── Target
│   └── Crosswalk
├── Reconciliation
│   ├── Compare
│   └── Differences
├── Exceptions / Deviations
│   └── Exception Detail
├── Reporting
└── Settings / Administration
```

Treat Source / Target / Differences as tabs within the same workspace when they share the same selected project or record context.
