# ECCS Canvas App Shell Factory - UPDATED + UPLOAD & MAPPING

This package contains the 14 ECCS application shells plus the new ECCS Upload & Mapping shell for bulk configuration intake and source-to-Expanse DR mapping.

## Upload & Mapping utility
- Starter shell: `upload-mapping/ECCS - Upload & Mapping POC - Canvas Shell.msapp`
- Control target: `upload-mapping/CONTROL-BUILD-BLUEPRINT.md`
- Mapping/scoring logic: `upload-mapping/MAPPING-LOGIC.md`
- Dataverse contract: `upload-mapping/DATA-MODEL.md`
- Installation: `upload-mapping/INSTALL.md`
- Flow specifications: `flows/Power-Automate-Flow-Spec.md`
- Bulk upload templates: `templates/ECCS_Bulk_Mapping_Upload_Template.xlsx` and `.csv`

## Match grading
Primary 0-25%; Secondary 26-50%; Tertiary 51-75%; Complete 76-100%.

## Safe processing sequence
Upload -> Stage -> Map -> Score -> Review -> Approve -> Commit -> Audit

The shell does not perform a direct upload-to-DR write. DR commit is a separate approved-flow action.

## Existing ECCS shells
The 14 existing app/domain shells remain in their original folders. CNET is Cutover Nursing Entry Tool (CNET).
