# Power Automate Flow Specification

The Canvas shell should call these flows. They are specification files rather than importable production flows because connection references and environment-specific SQL/Dataverse connections must be selected in the target environment.

## Flow 1 - `ECCS Upload Parse and Stage`

Trigger: **Power Apps (V2)**

Inputs:
- BatchId
- FileName
- FileContent
- Domain

Actions:
1. Decode uploaded file content.
2. Validate extension and required headers.
3. Parse CSV/XLSX rows with a parser that preserves quoted fields and delimiters.
4. Write one `ECCS Upload Row` per source row.
5. Return staged row count, error count, and batch status.

## Flow 2 - `ECCS Build Mapping Candidates`

Trigger: Power Apps (V2) or Dataverse batch status update.

Actions:
1. Read staged rows for BatchId.
2. Normalize comparison fields.
3. Load target DR reference rows for the selected domain.
4. Generate candidates.
5. Calculate weighted score.
6. Assign MatchTier using configured thresholds.
7. Flag ties and no-match conditions.
8. Write `ECCS Mapping Result` rows.
9. Return summary counts.

## Flow 3 - `ECCS Commit Approved Mapping`

Trigger: Power Apps (V2).

Inputs:
- BatchId
- ApprovedBy
- TargetEnvironment

Actions:
1. Verify all submitted rows are approved.
2. Re-check batch/domain/environment.
3. Update/create target DR configuration by the domain-specific commit procedure.
4. Record commit execution ID and timestamp.
5. Return created/updated/error counts.

## Parser requirement

Do not use a simple `split()` expression for production CSV parsing because quoted commas, embedded delimiters and escaped quotes can corrupt columns. Use a robust CSV parsing step, Office Script, or another approved parser in the customer's Power Platform architecture.
