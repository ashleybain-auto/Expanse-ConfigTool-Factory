# Expanse Cutover Automation - MIS Provider - UPDATED Canvas App Shell

**Source configuration:** `Mapping_Expanse_PHA_Domainx.xlsb`
**Status:** configured from supplied workbook

## 1. What changed in this shell
- App title and domain/module text are set for **Expanse Cutover Automation - MIS Provider**.
- Header shows configured source areas: **ProviderDictionary | UserDictionary**.
- Search and facility filtering are part of the shell.
- Current/Proposed configuration, Action To Take, Save, Cancel, unsaved-change indicator, Target Match/Sync Check, and ECCS lineage are retained.
- The shell contains no CSV or source business-data rows.

## 2. Install the .msapp in DevelopmentAuto
1. Open the Power Apps maker portal and select the **DevelopmentAuto** environment.
2. Go to **Apps** and use **Import app > From file (.msapp)**.
3. Select the `.msapp` in this package.
4. After Studio loads the app, use **File > Save as** and retain the exact app name shown in `app-config.json`.
5. Open **Data** and remove/replace the starter `Accommodation Data Clone` source with the real domain Dataverse table/view.
6. Rebind the facility Combo box, gallery, Current Configuration fields, Proposed Configuration fields, Target Match, Action To Take, and ECCS lineage fields using `field-mapping-template.json`.
7. Update the `Patch()` object in the Save Configuration button to the real entity and Dataverse field types.
8. Test one record end-to-end, then run App Checker, Save, and Publish.

## 3. Attached-source configuration
### ProviderDictionary
- Refresh marker: `9/8/2026 10:17:16 AM`
- Approximate source data rows: `75656`
- Columns: `FacilityMnem_Source, FacilityShortName, WaveAssigned, ProviderMnemonic_Source, UserMnemonic_Source, ProviderNpiNum_Source, Provider34_Source, ProviderName_Source, TargetMatchMtx, DB_RecordCount_PHA_Active, DB_RecordCount_PHA_History, OM_Target_OrderingProviderFlag, DB_RecordCount_OM, REG_Target_AdmittingProviderFlag, DB_RecordCount_REG_Admit, DB_RecordCount_REG, UserMnemonic_Target, Action To Take`
- ECCS role: provider dictionary and multi-system target matching
### UserDictionary
- Refresh marker: `2/28/2025 3:52:25 PM`
- Approximate source data rows: `1`
- Columns: `MT56_FacilityMnem, MT56_UserMnemonic, MT56_UserName, DB_RecordCount, MTX_UserMnemonic, Action To Take`
- ECCS role: user dictionary mappings

## 4. Functional build formulas
### Facility Items
```powerfx
Sort(Distinct('DOMAIN TABLE', FacilityMnem_Source), Value, SortOrder.Ascending)
```
### Gallery Items
```powerfx
Filter(
    'DOMAIN TABLE',
    IsBlank(cmbFacility.Selected.Value) || FacilityMnem_Source = cmbFacility.Selected.Value,
    IsBlank(Trim(txtAccommodationSearch.Text)) ||
        StartsWith(Lower(Text(ProviderMnemonic_Source)), Lower(Trim(txtAccommodationSearch.Text))) ||
        StartsWith(Lower(Text(ProviderName_Source)), Lower(Trim(txtAccommodationSearch.Text)))
)
```
### Save/Patch pattern
```powerfx
Patch(
    'DOMAIN TABLE',
    galAccommodations.Selected,
    {
    UserMnemonic_Target: <control value for UserMnemonic_Target>,
    Action To Take: <Action To Take value>
    }
)
```
### Target Match / Sync rule
```powerfx
IsMatch(
    galAccommodations.Selected.TargetMatchMtx,
    "^(LIVE|TEST|ZCON) \([0-9]{4}-[0-9]{2}-[0-9]{2}\)$",
    MatchOptions.Contains
)
```

## 5. Acceptance checks
- Correct application title and module/domain.
- Correct facility list and filtering after real source rebinding.
- Search finds records by source mnemonic/name.
- Source values are read-only; proposed values are editable.
- Action To Take is selectable and persists with the record.
- Save marks the record updated and refreshes the gallery.
- Cancel restores the last committed values and clears the unsaved indicator.
- NO MATCH is red/bold and dated LIVE/TEST/ZCON matches invoke the synchronization prompt.
- ECCS lineage is traceable.
- App Checker has no new blocking errors.