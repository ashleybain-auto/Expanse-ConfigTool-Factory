# Expanse Cutover Automation - Non-Med/CONSULTS - UPDATED Canvas App Shell

**Source configuration:** `Mapping_Expanse_NONMED_Domainx.xlsb`
**Status:** configured from supplied workbook

## 1. What changed in this shell
- App title and domain/module text are set for **Expanse Cutover Automation - Non-Med/CONSULTS**.
- Header shows configured source areas: **Config_AppendQuery | ScreenQueryGroupResponseElement**.
- Search and facility filtering are part of the shell.
- Current/Proposed configuration, Action To Take, Save, Cancel, unsaved-change indicator, Target Match/Sync Check, and ECCS lineage are retained.
- The shell contains no CSV or source business-data rows.

## 2. Install the .msapp in DevelopmentAuto
1. Open the Power Apps maker portal and select the **DevelopmentAuto** environment.
2. Go to **Apps** and use **Import app > From file (.msapp)**.
3. Select the `.msapp` in this package.
4. After Studio loads the app, use **File > Save as** and retain the exact app name shown in `app-config.json`.
5. Open **Data** and remove/replace the starter `Accommodation Data Clone` source with the real domain Dataverse table/view.
6. Rebind the facility Combo box, gallery, Current Configuration fields, Proposed Configuration fields, Target Match, Action To Take, and ECCS lineage fields using `field-mapping-template.json`.
7. Update the `Patch()` object in the Save Configuration button to the real entity and Dataverse field types.
8. Test one record end-to-end, then run App Checker, Save, and Publish.

## 3. Attached-source configuration
### Config_AppendQuery
- Refresh marker: `4/14/2026 9:26:27 AM`
- Approximate source data rows: `566`
- Columns: `FacilityMnem_Source, CategoryMnem_Target, ProcedureMnem_Target, ScreenMnem_Target, QueryMnem_Target, SourceOfQueryOnOrder, QueryRequired, QueryValueType_Target, QueryResponse_Target, QueryResponseBehavior, DB_RecordCount, If Query(s) Present (X;Y;Z), If TRUE QueryResponse_Target, Action To Take`
- ECCS role: query append/configuration rules
### ScreenQueryGroupResponseElement
- Refresh marker: `1/5/2026 8:56:51 AM`
- Approximate source data rows: `10696`
- Columns: `FacilityMnem_Source, ScreenType_Source, ScreenMnem_Source, ScreenMnem_Target, PresentOnOrder(s), QueryMnem_Source, QueryTargetMatchMtx, QueryDesc_Source, QueryType_Source, QueryPointer_Source, QueryMultiYN_Source, DB_RecordCount, QueryMnem_Target, QueryMnem_Target2, QueryValueType_Target, GroupRespMnem_Source, GroupRespTargetMatchMtx, GroupRespElementMnem_Source, GroupRespElementDesc_Source, GroupRespElementMnem_Target, Action To Take`
- ECCS role: screen/query/group-response mappings

## 4. Functional build formulas
### Facility Items
```powerfx
Sort(Distinct('DOMAIN TABLE', FacilityMnem_Source), Value, SortOrder.Ascending)
```
### Gallery Items
```powerfx
Filter(
    'DOMAIN TABLE',
    IsBlank(cmbFacility.Selected.Value) || FacilityMnem_Source = cmbFacility.Selected.Value,
    IsBlank(Trim(txtAccommodationSearch.Text)) ||
        StartsWith(Lower(Text(QueryMnem_Target)), Lower(Trim(txtAccommodationSearch.Text))) ||
        StartsWith(Lower(Text(ProcedureMnem_Target)), Lower(Trim(txtAccommodationSearch.Text)))
)
```
### Save/Patch pattern
```powerfx
Patch(
    'DOMAIN TABLE',
    galAccommodations.Selected,
    {
    QueryMnem_Target: <control value for QueryMnem_Target>,
    QueryResponse_Target: <control value for QueryResponse_Target>,
    Action To Take: <Action To Take value>
    }
)
```
### Target Match / Sync rule
```powerfx
False until the domain supplies a Target Match field.
```

## 5. Acceptance checks
- Correct application title and module/domain.
- Correct facility list and filtering after real source rebinding.
- Search finds records by source mnemonic/name.
- Source values are read-only; proposed values are editable.
- Action To Take is selectable and persists with the record.
- Save marks the record updated and refreshes the gallery.
- Cancel restores the last committed values and clears the unsaved indicator.
- NO MATCH is red/bold and dated LIVE/TEST/ZCON matches invoke the synchronization prompt.
- ECCS lineage is traceable.
- App Checker has no new blocking errors.