# Functional Build - Expanse Cutover Automation - PHA/MED

Source: `Mapping_Expanse_PHA_Domainx.xlsb`

## Common functions
- single-select facility filtering
- text search against source mnemonic and source description/name
- results gallery with selected-record state
- current source configuration display
- proposed target configuration using Classic/TextInput@2.3.2
- Action To Take selector
- unsaved-change detection, Save and Cancel/Revert workflow
- Patch + Refresh save pattern with update user/date-time capture
- Target Match NO MATCH red/bold warning treatment
- active-environment sync confirmation for LIVE/TEST/ZCON dated matches
- ECCS lineage display retained from the Registration POC shell

## Source-specific configuration
- `Routes`: route mappings
- `DirectionsSigs`: direction/signature mappings
- `PhaOrderTypes`: pharmacy order type mappings
- `DrugDoseUnit`: drug dose unit mappings
- `PrnReason`: PRN reason mappings
- `PhaMisScreens`: PHA/MIS screen mappings
- `PhaMisQueries`: PHA/MIS query mappings
- `PhaMisGroupRespElements`: PHA/MIS group response element mappings
- `RxAdminCriteria`: Rx administration criteria
- `MedMnemExclusions`: medication mnemonic exclusions
- `LocationExclusions`: location exclusions
- `MedTypeExclusions`: medication type exclusions
- `DrugSiteRestrictions`: drug site restriction validation
- `ErrorConfiguration`: configured error thresholds