# Expanse Cutover Automation - PHA/MED - UPDATED Canvas App Shell

**Source configuration:** `Mapping_Expanse_PHA_Domainx.xlsb`
**Status:** configured from supplied workbook

## 1. What changed in this shell
- App title and domain/module text are set for **Expanse Cutover Automation - PHA/MED**.
- Header shows configured source areas: **Routes | DirectionsSigs | PhaOrderTypes | DrugDoseUnit | PrnReason | PhaMisScreens | PhaMisQueries | PhaMisGroupRespElements | RxAdminCriteria | MedMnemExclusions | LocationExclusions | MedTypeExclusions | DrugSiteRestrictions | ErrorConfiguration**.
- Search and facility filtering are part of the shell.
- Current/Proposed configuration, Action To Take, Save, Cancel, unsaved-change indicator, Target Match/Sync Check, and ECCS lineage are retained.
- The shell contains no CSV or source business-data rows.

## 2. Install the .msapp in DevelopmentAuto
1. Open the Power Apps maker portal and select the **DevelopmentAuto** environment.
2. Go to **Apps** and use **Import app > From file (.msapp)**.
3. Select the `.msapp` in this package.
4. After Studio loads the app, use **File > Save as** and retain the exact app name shown in `app-config.json`.
5. Open **Data** and remove/replace the starter `Accommodation Data Clone` source with the real domain Dataverse table/view.
6. Rebind the facility Combo box, gallery, Current Configuration fields, Proposed Configuration fields, Target Match, Action To Take, and ECCS lineage fields using `field-mapping-template.json`.
7. Update the `Patch()` object in the Save Configuration button to the real entity and Dataverse field types.
8. Test one record end-to-end, then run App Checker, Save, and Publish.

## 3. Attached-source configuration
### Routes
- Refresh marker: `10/27/2025 8:57:48 AM`
- Approximate source data rows: `2`
- Columns: `FacilityMnem_Source, RouteMnemonic_Source, RouteName_Source, DB_RecordCount, RouteMnemonic_Target, Action To Take`
- ECCS role: route mappings
### DirectionsSigs
- Refresh marker: `10/27/2025 9:17:39 AM`
- Approximate source data rows: `206`
- Columns: `FacilityMnem_Source, DirectionMnemonic_Source, DirectionDescription_Source, FreeTextInd, Modules, TargetMatchMtx_PHA, TargetMatchMtx_OM, DB_RecordCount, DirectionMnemonic_Target, OverrideSchedule_Target, StartDT_Calculation_Target, Action To Take`
- ECCS role: direction/signature mappings
### PhaOrderTypes
- Refresh marker: `10/6/2025 8:44:14 AM`
- Approximate source data rows: `137`
- Columns: `FacilityMnem_Source, OrderTypeMnemonic_Source, OrderTypeName_Source, OrderTypeDispenseBy_Source, OrderInternalType, TargetMatchMtx, DB_RecordCount, OrderTypeMnemomic_Target, Override_DirectionSig_Target, IsExcluded, SetAutoTMO_YN, Action To Take`
- ECCS role: pharmacy order type mappings
### DrugDoseUnit
- Refresh marker: `6/5/2025 3:17:58 PM`
- Approximate source data rows: `78497`
- Columns: `FacilityMnem_Source, DrugMnemonic_Source, DrugDescription_Source, SymedicalMappedDrugMnem (Ord/Disp Units)_Target, DoseUnit_Source, Units_Mismatch, DB_RecordCount, Multiplier_Target, DoseUnit_Target, Action To Take`
- ECCS role: drug dose unit mappings
### PrnReason
- Refresh marker: `2/28/2025 3:42:08 PM`
- Approximate source data rows: `1`
- Columns: `MT56_FacilityMnem, MT56_PrnReasonMnemonic, MT56_PrnReasonName, DB_RecordCount, MTX_PrnReasonMnemomic, Action To Take`
- ECCS role: PRN reason mappings
### PhaMisScreens
- Refresh marker: `5/8/2026 11:15:06 AM`
- Approximate source data rows: `11378`
- Columns: `FacilityMnem_Source, FacilityShortName, WaveAssigned, ScreenType_Source, ScreenMnemonic_Source, ScreenName_Source, TargetMatchMtx_MisScreen, TargetMatchMtx_Protocol, DB_RecordCount, ScreenMnemonic_Target, ProtocolMnemonic_Target, AddLabelCommentAndOverrideTMOtoNo_YN, Action To Take`
- ECCS role: PHA/MIS screen mappings
### PhaMisQueries
- Refresh marker: `2/28/2025 3:44:34 PM`
- Approximate source data rows: `1`
- Columns: `MT56_FacilityMnem, MT56_ScreenMnemonic, MT56_ScreenQueryMnemonic, MT56_ScreenQueryText, DB_RecordCount, MTX_ScreenQueryMnemonic, Action To Take`
- ECCS role: PHA/MIS query mappings
### PhaMisGroupRespElements
- Refresh marker: `2/28/2025 3:46:05 PM`
- Approximate source data rows: `1`
- Columns: `MT56_FacilityMnem, MT56_ScreenMnemonic, MT56_ScreenQuery, MT56_GrpRespMnem, MT56_GrpRespName, MT56_RankOrder, MT56_GrpRespElemMnem, MT56_GrpRespElemResp, DB_RecordCount, MTX_ScreenQuery, MTX_GrpRespMnem, MTX_GrpRespElemMnem, Action To Take`
- ECCS role: PHA/MIS group response element mappings
### RxAdminCriteria
- Refresh marker: `4/20/2026 12:04:11 PM`
- Approximate source data rows: `510`
- Columns: `FacilityMnem_Source, FacilityShortName, WaveAssigned, RxAdminCriteriaMnemonic_Source, RxAdminCriteriaDisplayName_Source, RxAdminCriteriaCdsMnem_Source, RxAdminCriteriaCdsMnem_Target, TargetMatchMtx, DB_RecordCount, OMProtocolMnemonic_Target, AddLabelCommentAndOverideTMOtoNo_YN, Action To Take`
- ECCS role: Rx administration criteria
### MedMnemExclusions
- Refresh marker: `9/9/2025 10:15:54 AM`
- Approximate source data rows: `6484`
- Columns: `MedMnem_Target, MedDrugId_Target, ActiveFlag, IsExcluded, ReasonExcluded, IsStopDateTimeRequiredInHL7, SetAutoTMO_YN, Action To Take`
- ECCS role: medication mnemonic exclusions
### LocationExclusions
- Refresh marker: `9/9/2025 10:16:28 AM`
- Approximate source data rows: `18318`
- Columns: `FacilityMnem_Source, LocationMnem_Source, LocationActive_Source, FacilityMnem_Target, LocationMnem_Target, IsExcluded, ReasonExcluded, SetAutoTMO_YN, Action To Take`
- ECCS role: location exclusions
### MedTypeExclusions
- Refresh marker: `9/9/2025 10:16:33 AM`
- Approximate source data rows: `94`
- Columns: `MedTypeMnem_Target, ActiveFlag, IsExcluded, ReasonExcluded, IsStopDateTimeRequiredInHL7, SetAutoTMO_YN, Action To Take`
- ECCS role: medication type exclusions
### DrugSiteRestrictions
- Refresh marker: `5/8/2026 11:49:21 AM`
- Approximate source data rows: `7589`
- Columns: `FacilityMnem_Source, FacilityShortName, WaveAssigned, LocationMnem_Target, DrugMnem_Source, DrugMnem_Target, OrderSite, TotalMedOrders_TEST, RestrictedBySite_TEST, CrosswalkIssue_TEST, TotalMedOrders_ZCON, RestrictedBySite_ZCON, CrosswalkIssue_ZCON, TotalMedOrders_LIVE, RestrictedBySite_LIVE, CrosswalkIssue_LIVE, ExampleAccounts, UserComments, Action To Take`
- ECCS role: drug site restriction validation
### ErrorConfiguration
- Refresh marker: `9/1/2026 11:39:59 AM`
- Approximate source data rows: `14`
- Columns: `WaveAssigned, FacilityMnem_Target, ErrorCategory, EstimatedErrorPercentage, ActualErrorPercentage, Action To Take, update_user, update_datetime`
- ECCS role: configured error thresholds

## 4. Functional build formulas
### Facility Items
```powerfx
Sort(Distinct('DOMAIN TABLE', FacilityMnem_Source), Value, SortOrder.Ascending)
```
### Gallery Items
```powerfx
Filter(
    'DOMAIN TABLE',
    IsBlank(cmbFacility.Selected.Value) || FacilityMnem_Source = cmbFacility.Selected.Value,
    IsBlank(Trim(txtAccommodationSearch.Text)) ||
        StartsWith(Lower(Text(RouteMnemonic_Source)), Lower(Trim(txtAccommodationSearch.Text))) ||
        StartsWith(Lower(Text(RouteName_Source)), Lower(Trim(txtAccommodationSearch.Text)))
)
```
### Save/Patch pattern
```powerfx
Patch(
    'DOMAIN TABLE',
    galAccommodations.Selected,
    {
    RouteMnemonic_Target: <control value for RouteMnemonic_Target>,
    Action To Take: <Action To Take value>
    }
)
```
### Target Match / Sync rule
```powerfx
False until the domain supplies a Target Match field.
```

## 5. Acceptance checks
- Correct application title and module/domain.
- Correct facility list and filtering after real source rebinding.
- Search finds records by source mnemonic/name.
- Source values are read-only; proposed values are editable.
- Action To Take is selectable and persists with the record.
- Save marks the record updated and refreshes the gallery.
- Cancel restores the last committed values and clears the unsaved indicator.
- NO MATCH is red/bold and dated LIVE/TEST/ZCON matches invoke the synchronization prompt.
- ECCS lineage is traceable.
- App Checker has no new blocking errors.