# ECCS Upload & Mapping Canvas Shell - Control Blueprint

Use this blueprint to convert the supplied Registration POC starter app into the bulk upload/mapping application. The compiled `.msapp` is intentionally retained as the proven ECCS shell baseline; the controls below are the implementation target inside Power Apps Studio.

## Screen: `scrUploadMapping`

- `lblAppTitle` - ECCS - Upload & Mapping
- `lblModuleTitle` - Bulk Configuration Upload | Source -> Expanse DR
- `cmbDomain` - select ECCS automation/domain
- `txtBatchName` - batch identifier
- `frmUploadBatch` - Dataverse form bound to `ECCS Upload Batch`
- `attConfigFile` - Attachments control inside the form; accepts the upload file
- `btnCreateBatch` - creates/saves the batch
- `btnRunParse` - invokes the parse/stage flow
- `lblUploadStatus` - batch status
- `lblUploadSummary` - rows received/staged/errors
- `galUploadRows` - staged source rows

## Screen: `scrMappingReview`

- `cmbTierFilter` - Primary / Secondary / Tertiary / Complete
- `cmbMatchStatusFilter` - Candidate / Matched / No Match / Exception
- `txtSearchMapping` - facility/mnemonic/name search
- `galMappingResults` - source row + proposed DR target + score
- `lblMatchPercent` - numeric score
- `lblMatchTier` - tier grade
- `lblMatchedFields` - count and names of matching fields
- `lblSuggestedAction` - Create / Update / Review / Exclude
- `btnAcceptMatch` - accept proposed mapping
- `btnOverrideMatch` - manually select a target
- `btnMarkReview` - send to review queue

## Screen: `scrMappingCommit`

- KPI cards for Source Rows, Complete, Tertiary, Secondary, Primary, No Match, Exceptions
- `galCommitPreview` - final mapping preview
- `btnCommitApproved` - explicit commit to DR through controlled flow
- `btnCancelCommit` - return to review
- `lblCommitStatus` - result and timestamp

## Core common functions

1. Upload file -> stage batch.
2. Normalize source values.
3. Find target DR candidates.
4. Calculate weighted match percent.
5. Convert percent to Primary / Secondary / Tertiary / Complete.
6. Present candidate and matched-field explanation.
7. Require explicit acceptance for non-Complete records.
8. Stage approved rows.
9. Commit only approved mappings to DR.
10. Capture ECCS lineage, user and timestamp.
