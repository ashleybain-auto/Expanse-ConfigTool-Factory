# ECCS Upload and Mapping Data Model

## ECCS Upload Batch

Recommended columns:

- BatchId
- BatchName
- Domain
- SourceSystem
- TargetSystem = `EXPANSE-DR`
- FileName
- FileType
- UploadedBy
- UploadedDateTime
- RowCount
- ErrorCount
- Status

## ECCS Upload Row

Recommended columns:

- UploadRowId
- BatchId
- RowNumber
- SourceRecordJson (or mapped source columns)
- Facility_Source
- Mnemonic_Source
- Name_Source
- PA_Code_Source
- Active_Source
- ProcessingStatus
- ParseError

## ECCS Target DR Reference

Recommended columns:

- TargetRowId
- Facility_Target
- Mnemonic_Target
- Name_Target
- PA_Code_Target
- Active_Target
- Domain
- Environment = `DR`
- RecordStatus

## ECCS Mapping Result

Recommended columns:

- MappingResultId
- BatchId
- UploadRowId
- TargetRowId
- MatchPercent
- MatchTier
- MatchedFieldList
- CandidateCount
- TieFlag
- SuggestedAction
- ApprovalStatus
- ApprovedBy
- ApprovedDateTime
- CommitStatus
- CommitExecutionId
- CommitDateTime
- ErrorMessage
- ECCS_SourceFile
- ECCS_SourceRow
