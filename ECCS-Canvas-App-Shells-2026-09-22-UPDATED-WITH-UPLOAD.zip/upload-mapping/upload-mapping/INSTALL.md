# ECCS Upload & Mapping Shell - Installation and Build

## Target environment

`DevelopmentAuto`

Power Apps maker baseline:
`0.0.20260918.2-2609.2-prod`

## Step 1 - Import the starter Canvas App

1. Sign in to Power Apps.
2. Open the Apps area in the `DevelopmentAuto` environment.
3. Choose **Import app > From file (.msapp)**.
4. Select `ECCS - Upload & Mapping POC - Canvas Shell.msapp`.
5. When Studio opens the app, use **Save as** and create `ECCS - Upload & Mapping POC`.
6. Do not overwrite the working Registration POC.

Microsoft documents single-app `.msapp` import from **Apps > Import app > From file (.msapp)**. See the source link recorded in the developer build document.

## Step 2 - Create or confirm staging tables

Create these Dataverse tables before completing the app:

- ECCS Upload Batch
- ECCS Upload Row
- ECCS Target DR Reference
- ECCS Mapping Result

Use the field lists in `DATA-MODEL.md` as the baseline schema.

## Step 3 - Build the upload screen

Use `CONTROL-BUILD-BLUEPRINT.md` to add `scrUploadMapping` and its controls.

The file attachment control must be inside a form bound to the Upload Batch table because the Power Apps Attachments control saves uploaded files through a form context.

## Step 4 - Add the parse/stage flow

Create `ECCS Upload Parse and Stage` using `flows/Power-Automate-Flow-Spec.md`.

Add the flow to the Canvas App and connect `btnRunParse` to it.

Example pattern:

```powerfx
Set(
    gblParseResult,
    'ECCS Upload Parse and Stage'.Run(
        gblBatchId,
        First(attConfigFile.Attachments).Name,
        First(attConfigFile.Attachments).Value,
        cmbDomain.Selected.Value
    )
);
Refresh('ECCS Upload Row');
```

Adjust the flow name and attachment property names to the generated flow connection.

## Step 5 - Build mapping logic

Use `MAPPING-LOGIC.md`.

Default bands:

- Primary: 0-25%
- Secondary: 26-50%
- Tertiary: 51-75%
- Complete: 76-100%

Default weighting:

- Facility 30%
- Mnemonic 30%
- Name/Description 20%
- PA/secondary key 10%
- Active 10%

Keep these values in configuration so domain owners can change them without rewriting the app.

## Step 6 - Add review and approval behavior

The review gallery should show:

`Source -> Proposed Target -> Match % -> Match Tier -> Matched Fields -> Suggested Action`

A Complete match may be accepted through the standard approval path. Tertiary/Secondary/Primary matches should retain explicit review/override behavior. Ties and no-match conditions are exceptions.

## Step 7 - Add commit flow

Create `ECCS Commit Approved Mapping` and connect `btnCommitApproved`.

The commit flow must operate only on approved staging rows and must write the execution ID, user and timestamp back to `ECCS Mapping Result`.

## Step 8 - Test with the template

Use:

`templates/ECCS_Bulk_Mapping_Upload_Template.xlsx`

and

`templates/ECCS_Bulk_Mapping_Upload_Template.csv`

Expected test sequence:

1. Upload file.
2. Create batch.
3. Parse/stage rows.
4. Build mapping candidates.
5. Verify score/tier.
6. Accept/override.
7. Preview commit.
8. Commit approved rows.
9. Verify audit fields.

## Step 9 - App Checker / Publish

Run App Checker, correct errors, save, and publish. Test the app in Play mode using a nonproduction DR/test target before introducing production connection references.

## Step 10 - Power Pages placement

After the app has an App ID, use its Power Apps play URL for the ECCS Power Pages Application Hub. Microsoft documents embedding a canvas app in an iframe with an `apps.powerapps.com/play/[AppID]?source=...` URL.
