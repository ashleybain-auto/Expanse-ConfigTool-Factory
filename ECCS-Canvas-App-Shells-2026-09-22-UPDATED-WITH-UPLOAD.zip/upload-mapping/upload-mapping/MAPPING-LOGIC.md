# ECCS Bulk Upload and Source -> Expanse DR Mapping Logic

## 1. Match grading

The default configurable grading bands are:

| Score | Tier | Meaning in the app |
|---:|---|---|
| 0-25% | Primary | Low-confidence candidate; manual review expected |
| 26-50% | Secondary | Partial match; review expected |
| 51-75% | Tertiary | Strong partial match; verify target before commit |
| 76-100% | Complete | Highest score band; eligible for normal approval workflow |

These bands are stored as configuration, not hard-coded business policy, so they can be changed by the ECCS configuration owner.

## 2. Default weighted scoring

The starter weighting is:

- Facility = 30%
- Mnemonic = 30%
- Name/Description = 20%
- PA Code or secondary key = 10%
- Active = 10%

The score is the sum of the weights for fields that match after normalization. Domain-specific configurations can replace these fields and weights.

## 3. Normalization

Recommended starter normalization for text comparison:

```powerfx
Upper(
    Trim(
        Substitute(
            Substitute(
                Substitute(
                    Coalesce(Value, ""),
                    "-",
                    " "
                ),
                "_",
                " "
            ),
            "/",
            " "
        )
    )
)
```

Use the normalized value only for comparison. Preserve the original uploaded value for lineage/audit.

## 4. Generic score formula

Replace the field names with the domain-specific source and target columns.

```powerfx
With(
    {
        sFacility: Upper(Trim(Coalesce(ThisItem.Facility_Source, ""))),
        sMnem: Upper(Trim(Coalesce(ThisItem.Mnemonic_Source, ""))),
        sName: Upper(Trim(Coalesce(ThisItem.Name_Source, ""))),
        sPA: Upper(Trim(Coalesce(ThisItem.PA_Code_Source, ""))),
        sActive: Upper(Trim(Coalesce(ThisItem.Active_Source, ""))),
        tFacility: Upper(Trim(Coalesce(ThisItem.Facility_Target, ""))),
        tMnem: Upper(Trim(Coalesce(ThisItem.Mnemonic_Target, ""))),
        tName: Upper(Trim(Coalesce(ThisItem.Name_Target, ""))),
        tPA: Upper(Trim(Coalesce(ThisItem.PA_Code_Target, ""))),
        tActive: Upper(Trim(Coalesce(ThisItem.Active_Target, "")))
    },
    Round(
        100 * (
            If(sFacility <> "" && sFacility = tFacility, 0.30, 0) +
            If(sMnem <> "" && sMnem = tMnem, 0.30, 0) +
            If(sName <> "" && sName = tName, 0.20, 0) +
            If(sPA <> "" && sPA = tPA, 0.10, 0) +
            If(sActive <> "" && sActive = tActive, 0.10, 0)
        ),
        0
    )
)
```

## 5. Tier formula

```powerfx
With(
    { pct: Value(lblMatchPercent.Text) },
    Switch(
        true,
        pct <= 25, "Primary",
        pct <= 50, "Secondary",
        pct <= 75, "Tertiary",
        "Complete"
    )
)
```

## 6. Candidate selection

The mapping engine should first constrain by the strongest available key, normally Facility. It should then compare the candidate target rows and retain the highest score. A tie must remain a review condition rather than silently selecting one target.

Conceptual pattern:

```powerfx
With(
    {
        candidates: Filter(
            'ECCS Target DR Reference',
            Upper(Trim(FacilityMnem)) = Upper(Trim(ThisItem.Facility_Source))
        )
    },
    First(
        Sort(
            AddColumns(candidates, MatchScore, /* domain score expression */),
            MatchScore,
            SortOrder.Descending
        )
    )
)
```

For production use, put the score calculation in the staging/mapping layer rather than repeating a large expression across multiple controls.

## 7. Suggested action rules

```text
Complete + unique candidate       -> Review/Accept
Tertiary + unique candidate       -> Review required
Secondary                          -> Manual mapping required
Primary                            -> Manual mapping required
No candidate                       -> No Match
Tied top candidates                -> Exception
Explicit exclusion                -> Exclude
```

## 8. Commit guardrails

The upload screen must not directly write an uploaded CSV row to the Expanse DR database. The intended sequence is:

`Upload -> Stage -> Map -> Score -> Review -> Approve -> Commit -> Audit`

The `btnCommitApproved` action calls a Power Automate/SQL commit flow that writes only approved staging rows and returns an execution ID and result counts.
