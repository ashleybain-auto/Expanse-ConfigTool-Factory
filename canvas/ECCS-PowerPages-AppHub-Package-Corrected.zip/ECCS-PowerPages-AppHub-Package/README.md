# ECCS Power Pages Application Hub Package

This package implements the **Expanse Configuration & Conversion Suite (ECCS) Application Hub** as a Power Pages front end for the ECCS application family shown in the supplied reference screens.

## What is included

### 1. `code-site/`
A self-contained Power Pages Single-Page Application (SPA) implementation. It provides:
- Expanse / HCA-style shell using the supplied brand palette:
  - HCA Navy `#03173E`
  - HCA Orange `#E05929`
  - Dark Gray `#54585A`
  - Arial-first typography
- Solution-level tabs
- Nested application tabs
- Search across the 15 ECCS applications
- Active app state, breadcrumb, and app description
- Configurable Power Apps iframe embedding
- Full-app launch button
- App ID / URL configuration handled outside the HTML through `config/app-registry.json`
- Responsive layout for desktop and tablet use

### 2. `traditional-site-overlay/`
A page-level HTML/CSS/JavaScript overlay intended for the user's **existing Power Pages site** at:
`https://expanseautomationcutoversuite.powerappsportals.com/`

Use this when the existing site is a traditional/standard Power Pages site and should retain its current site shell/navigation. The overlay contains the ECCS hub screen and embeds the configured Canvas apps in-place.

### 3. `config/app-registry.json`
Central registry for all 15 ECCS applications. Each record has an `appId`, `launchUrl`, solution grouping, and display metadata. Replace the placeholder values with the real Canvas App IDs/URLs.

### 4. `docs/`
Deployment and configuration notes, including the distinction between Power Pages SPA deployment and adding a page to an existing traditional Power Pages site.

## Application hierarchy

```text
ECCS Application Hub
|
+-- Registration
|   +-- Registration/PTAC
|
+-- Emergency Department
|   +-- Emergency Department
|
+-- Non-Med
|   +-- RAD
|   +-- LAB
|   +-- DIET
|   +-- OE
|   +-- CONSULTS
|   +-- LEVEL OF CARE
|   +-- NURSING
|   +-- RT-PT-OT
|   +-- EKG
|
+-- Pharmacy
|   +-- PHA/MED
|
+-- Provider
|   +-- MIS Provider
|
+-- Cutover Nursing Entry Tool (CNET)
    +-- CNET
```

## Configure Power Apps

Edit:
`config/app-registry.json`

For each application populate `appId` and/or `launchUrl`. The package accepts the standard Canvas App play URL form:
`https://apps.powerapps.com/play/<APP_ID>?source=iframe`

The iframe is intentionally not populated until a real App ID/URL is supplied, so the package cannot accidentally launch a wrong application.

## Deployment options

### Existing Power Pages site
Use the `traditional-site-overlay` content with the existing site. This is the path for the user's current `powerappsportals.com` site unless that site has been converted to a code-site/SPA implementation.

### New Power Pages SPA site
Use the `code-site` folder with:

```powershell
pac pages upload-code-site --rootPath .\code-site
```

The included `powerpages.config.json` supplies the site name, compiled path, and landing page.

## Important

This package is the **site front-end and app registry**, not the Canvas Apps themselves. It does not invent or alter the configured functions inside the 15 Canvas Apps. It provides the navigation shell and the insertion points for the actual apps.

Before production deployment, populate the real app IDs/launch URLs and validate Power Pages authentication/permissions and the tenant access requirements for embedded Canvas Apps.
