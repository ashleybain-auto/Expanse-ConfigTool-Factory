(async function () {
  const $ = (id) => document.getElementById(id);
  let registry;
  try {
    const response = await fetch('assets/eccs-app-registry.json', { cache: 'no-store' });
    if (!response.ok) throw new Error(`Registry request failed: ${response.status}`);
    registry = await response.json();
  } catch (error) {
    const placeholder = $('embedPlaceholder');
    placeholder.innerHTML = '<div class="placeholder-icon">!</div><h3>ECCS configuration not loaded</h3><p>Publish assets/eccs-app-registry.json with this site package, then refresh the page.</p>';
    return;
  }

  const state = { solutionId: registry.solutions[0]?.id, appId: registry.site.defaultApp };
  const appById = new Map(registry.apps.map(app => [app.id, app]));
  const activeSolution = () => registry.solutions.find(s => s.id === state.solutionId) || registry.solutions[0];
  const appLaunchUrl = (app) => {
    if (!app) return '';
    if (app.launchUrl && !app.launchUrl.includes('REPLACE')) return app.launchUrl;
    if (app.appId && app.appId !== 'REPLACE_APP_ID') return `https://apps.powerapps.com/play/${encodeURIComponent(app.appId)}?source=iframe`;
    return '';
  };

  function setText(id, value) { $(id).textContent = value; }

  function renderSolutionTabs() {
    const host = $('solutionTabs');
    host.innerHTML = registry.solutions.map(s =>
      `<button class="solution-tab ${s.id === state.solutionId ? 'active' : ''}" role="tab" aria-selected="${s.id === state.solutionId}" data-solution="${s.id}">${s.label}</button>`
    ).join('');
    host.querySelectorAll('[data-solution]').forEach(btn => btn.addEventListener('click', () => {
      state.solutionId = btn.dataset.solution;
      state.appId = activeSolution().apps[0];
      render();
    }));
  }

  function renderApplicationTabs(list = null) {
    const apps = (list || activeSolution().apps).map(id => appById.get(id)).filter(Boolean);
    const host = $('applicationTabs');
    host.innerHTML = apps.map(app =>
      `<button class="application-tab ${app.id === state.appId ? 'active' : ''}" role="tab" aria-selected="${app.id === state.appId}" data-app="${app.id}"><span aria-hidden="true">${app.icon}</span> ${app.tabLabel}</button>`
    ).join('');
    host.querySelectorAll('[data-app]').forEach(btn => btn.addEventListener('click', () => {
      state.appId = btn.dataset.app;
      render();
    }));
  }

  function renderWorkspace() {
    const app = appById.get(state.appId) || registry.apps[0];
    const sol = activeSolution();
    const url = appLaunchUrl(app);
    setText('breadcrumb', `${registry.site.shortName} > ${sol.label} > ${app.tabLabel}`);
    setText('appTitle', app.tabLabel);
    setText('appDescription', app.description);
    setText('solutionTitle', sol.label);
    setText('solutionDescription', sol.description);
    const frame = $('powerAppFrame');
    const placeholder = $('embedPlaceholder');
    const launch = $('launchApp');
    const configured = $('openConfigured');
    if (url) {
      placeholder.hidden = true;
      frame.hidden = false;
      if (frame.src !== url) frame.src = url;
      launch.disabled = false;
      configured.disabled = false;
      launch.onclick = () => window.open(url, '_blank', 'noopener,noreferrer');
      configured.onclick = () => window.open(url, '_blank', 'noopener,noreferrer');
    } else {
      placeholder.hidden = false;
      frame.hidden = true;
      frame.removeAttribute('src');
      launch.disabled = true;
      configured.disabled = true;
    }
  }

  function render() {
    renderSolutionTabs();
    renderApplicationTabs();
    renderWorkspace();
  }

  function searchApps(term) {
    const q = term.trim().toLowerCase();
    if (!q) { renderApplicationTabs(); return; }
    const matches = registry.apps.filter(app => [app.name, app.tabLabel, app.description].some(v => v.toLowerCase().includes(q)));
    renderApplicationTabs(matches.map(a => a.id));
    document.querySelectorAll('[data-app]').forEach(btn => btn.addEventListener('click', () => {
      const app = appById.get(btn.dataset.app);
      state.appId = app.id;
      state.solutionId = app.solutionId;
      render();
    }));
  }

  $('appSearch').addEventListener('input', e => searchApps(e.target.value));
  $('openPortal').addEventListener('click', () => window.open(registry.site.portalUrl, '_blank', 'noopener,noreferrer'));
  document.querySelectorAll('.side-link').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.side-link').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    if (btn.dataset.action === 'refresh') window.location.reload();
    if (btn.dataset.action === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
    if (btn.dataset.action === 'solutions') $('solutionTabs').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));

  render();
})();
