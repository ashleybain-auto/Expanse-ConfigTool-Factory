# ECCS Application Registry Configuration

Edit the single source of truth:

`config/app-registry.json`

For each of the 14 ECCS Canvas Apps, enter either:

- `appId`: the Canvas App GUID/ID; or
- `launchUrl`: a complete Power Apps play URL.

The site constructs the standard embedded URL when only `appId` is supplied:

`https://apps.powerapps.com/play/<APP_ID>?source=iframe`

For the code-site deployment, copy the updated registry to:

`code-site/dist/assets/eccs-app-registry.json`

The code-site JavaScript loads that file at runtime.

For the traditional Power Pages deployment, publish the same JSON as the web file:

`/eccs-app-registry.json`

Then use the supplied `ECCS-AppHub.page.html`, which references `/eccs-app-registry.json`.
