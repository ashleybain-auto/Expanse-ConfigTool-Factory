# ECCS Application Hub Deployment

## A. Existing Power Pages portal

Target site:
`https://expanseautomationcutoversuite.powerappsportals.com/`

For an existing traditional Power Pages site, the safest deployment path is to add the supplied HTML as a web page / web template and publish the CSS, JavaScript, and registry as web files. The page then renders the nested solution tabs and embedded Canvas App iframe.

Recommended web files:
- `eccs-apphub.css`
- `eccs-apphub.js`
- `eccs-app-registry.json`

Recommended page content:
- use `ECCS-AppHub.page.html` as the page body / custom template content

Before publishing, replace the placeholder app IDs in `eccs-app-registry.json`.

## B. New Power Pages SPA site

The `code-site` folder is structured for the current Power Pages code-site / SPA tooling.

```powershell
pac pages upload-code-site --rootPath .\code-site
```

The included `powerpages.config.json` sets the site name, compiled output directory, and default landing page.

After upload, activate the site in Power Pages and test the root URL.

## C. Existing site versus SPA

Do not use `pac pages upload-code-site` against a traditional site as a way to inject a page into that existing site. The SPA command is for Power Pages code-site deployment. For a traditional site, use the overlay assets/page content; for a code site, use the `code-site` package.

## D. Canvas App embedding

Each application is intentionally represented by a configuration record, not by an invented app ID. When an app record has a real `appId`, the hub constructs:

`https://apps.powerapps.com/play/<APP_ID>?source=iframe`

When a record has a `launchUrl`, that URL is used directly.

## E. Validation before production

1. Verify every application has the correct Canvas App ID or launch URL.
2. Sign in using a user who is authorized for the Canvas Apps.
3. Test each nested tab and the full-app launch action.
4. Confirm any app-specific environment variables, Dataverse permissions, connectors, and Power Pages authentication requirements.
5. Test at desktop and tablet widths.
