(async function(){
  const host=document.getElementById('eccs-apphub');
  if(!host) return;
  const registryPath=host.dataset.registry||'/eccs-app-registry.json';
  const els={solutions:document.getElementById('eccs-solutions'),apps:document.getElementById('eccs-apps'),search:document.getElementById('eccs-search'),title:document.getElementById('eccs-title'),desc:document.getElementById('eccs-description'),bread:document.getElementById('eccs-breadcrumb'),frame:document.getElementById('eccs-frame'),placeholder:document.getElementById('eccs-placeholder'),launch:document.getElementById('eccs-launch')};
  let cfg;
  try{ const r=await fetch(registryPath,{cache:'no-store'}); cfg=await r.json(); } catch(e){ els.placeholder.innerHTML='<strong>ECCS registry unavailable</strong><span>Publish eccs-app-registry.json as a Power Pages web file and retry.</span>'; return; }
  const appById=new Map(cfg.apps.map(a=>[a.id,a]));
  let solutionId=cfg.site.defaultSolution.toLowerCase().replace(/\s+/g,'-');
  let appId=cfg.site.defaultApp;
  function sol(){return cfg.solutions.find(s=>s.id===solutionId)||cfg.solutions[0]}
  function url(a){if(a.launchUrl)return a.launchUrl;if(a.appId&&a.appId!=='REPLACE_APP_ID')return `https://apps.powerapps.com/play/${encodeURIComponent(a.appId)}?source=iframe`;return ''}
  function renderSolutions(){els.solutions.innerHTML=cfg.solutions.map(s=>`<button type="button" class="eccs-solution-tab ${s.id===solutionId?'active':''}" data-s="${s.id}">${s.label}</button>`).join('');els.solutions.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{solutionId=b.dataset.s;appId=sol().apps[0];render()})}
  function renderApps(){const a=sol().apps.map(id=>appById.get(id)).filter(Boolean);els.apps.innerHTML=a.map(x=>`<button type="button" class="eccs-app-tab ${x.id===appId?'active':''}" data-a="${x.id}">${x.tabLabel}</button>`).join('');els.apps.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{appId=b.dataset.a;render()})}
  function renderWorkspace(){const a=appById.get(appId)||cfg.apps[0],s=sol(),u=url(a);els.bread.textContent=`ECCS > ${s.label} > ${a.tabLabel}`;els.title.textContent=a.tabLabel;els.desc.textContent=a.description;if(u){els.placeholder.hidden=true;els.frame.hidden=false;els.frame.src=u;els.launch.disabled=false;els.launch.onclick=()=>window.open(u,'_blank','noopener,noreferrer')}else{els.placeholder.hidden=false;els.frame.hidden=true;els.frame.removeAttribute('src');els.launch.disabled=true}}
  function render(){renderSolutions();renderApps();renderWorkspace()}
  els.search.oninput=()=>{const q=els.search.value.trim().toLowerCase();if(!q){renderApps();return}const matches=cfg.apps.filter(a=>[a.name,a.tabLabel,a.description].some(v=>v.toLowerCase().includes(q)));els.apps.innerHTML=matches.map(x=>`<button type="button" class="eccs-app-tab ${x.id===appId?'active':''}" data-a="${x.id}">${x.tabLabel}</button>`).join('');els.apps.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{const a=appById.get(b.dataset.a);appId=a.id;solutionId=a.solutionId;render()})};
  render();
})();
