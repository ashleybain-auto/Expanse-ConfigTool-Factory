# Expanse Cutover Automation - Emergency Department - UPDATED Canvas App Shell

**Source configuration:** `ACOE_Expanse_ConfigTool_EdmAutomationx.xlsb`
**Status:** configured from supplied workbook

## 1. What changed in this shell
- App title and domain/module text are set for **Expanse Cutover Automation - Emergency Department**.
- Header shows configured source areas: **Complaints | TreatmentAreaStations | Priorities**.
- Search and facility filtering are part of the shell.
- Current/Proposed configuration, Action To Take, Save, Cancel, unsaved-change indicator, Target Match/Sync Check, and ECCS lineage are retained.
- The shell contains no CSV or source business-data rows.

## 2. Install the .msapp in DevelopmentAuto
1. Open the Power Apps maker portal and select the **DevelopmentAuto** environment.
2. Go to **Apps** and use **Import app > From file (.msapp)**.
3. Select the `.msapp` in this package.
4. After Studio loads the app, use **File > Save as** and retain the exact app name shown in `app-config.json`.
5. Open **Data** and remove/replace the starter `Accommodation Data Clone` source with the real domain Dataverse table/view.
6. Rebind the facility Combo box, gallery, Current Configuration fields, Proposed Configuration fields, Target Match, Action To Take, and ECCS lineage fields using `field-mapping-template.json`.
7. Update the `Patch()` object in the Save Configuration button to the real entity and Dataverse field types.
8. Test one record end-to-end, then run App Checker, Save, and Publish.

## 3. Attached-source configuration
### Complaints
- Refresh marker: `9/11/2026 4:02:36 PM`
- Approximate source data rows: `2026`
- Columns: `FacilityMnem_Source, FacilityShortName, DivisionName, WaveAssigned, ComplaintMnem_Source, ComplaintDesc_Source, ActiveFlag_Source, MtxComparison, DB_RecordCount, ComplaintMnem_Target, ComplaintDesc_Target, Action To Take`
- ECCS role: complaint mappings
### TreatmentAreaStations
- Refresh marker: `9/11/2026 4:02:41 PM`
- Approximate source data rows: `5603`
- Columns: `FacilityMnem_Source, FacilityShortName, DivisionName, WaveAssigned, MisLocationMnem_Source, MisLocationDesc_Source, EdLocationMnem_Source, EdLocationDesc_Source, EdRoomMnem_Source, EdRoomDesc_Source, ActiveFlag_Source, MtxComparison, DB_RecordCount, MisLocationMnem_Target, EdLocationMnem_Target, EdLocationDesc_Target, TreatmentAreaMnem_Target, TreatmentAreaDesc_Target, StationMnem_Target, Action To Take`
- ECCS role: treatment area/station mappings
### Priorities
- Refresh marker: `9/11/2026 4:02:45 PM`
- Approximate source data rows: `225`
- Columns: `FacilityMnem_Source, FacilityShortName, DivisionName, WaveAssigned, PriorityMnem_Source, PriorityDesc_Source, ActiveFlag_Source, MtxComparison, DB_RecordCount, PriorityMnem_Target, PriorityDesc_Target, Action To Take`
- ECCS role: ED priority mappings

## 4. Functional build formulas
### Facility Items
```powerfx
Sort(Distinct('DOMAIN TABLE', FacilityMnem_Source), Value, SortOrder.Ascending)
```
### Gallery Items
```powerfx
Filter(
    'DOMAIN TABLE',
    IsBlank(cmbFacility.Selected.Value) || FacilityMnem_Source = cmbFacility.Selected.Value,
    IsBlank(Trim(txtAccommodationSearch.Text)) ||
        StartsWith(Lower(Text(ComplaintMnem_Source)), Lower(Trim(txtAccommodationSearch.Text))) ||
        StartsWith(Lower(Text(ComplaintDesc_Source)), Lower(Trim(txtAccommodationSearch.Text)))
)
```
### Save/Patch pattern
```powerfx
Patch(
    'DOMAIN TABLE',
    galAccommodations.Selected,
    {
    ComplaintMnem_Target: <control value for ComplaintMnem_Target>,
    ComplaintDesc_Target: <control value for ComplaintDesc_Target>,
    Action To Take: <Action To Take value>
    }
)
```
### Target Match / Sync rule
```powerfx
IsMatch(
    galAccommodations.Selected.MtxComparison,
    "^(LIVE|TEST|ZCON) \([0-9]{4}-[0-9]{2}-[0-9]{2}\)$",
    MatchOptions.Contains
)
```

## 5. Acceptance checks
- Correct application title and module/domain.
- Correct facility list and filtering after real source rebinding.
- Search finds records by source mnemonic/name.
- Source values are read-only; proposed values are editable.
- Action To Take is selectable and persists with the record.
- Save marks the record updated and refreshes the gallery.
- Cancel restores the last committed values and clears the unsaved indicator.
- NO MATCH is red/bold and dated LIVE/TEST/ZCON matches invoke the synchronization prompt.
- ECCS lineage is traceable.
- App Checker has no new blocking errors.