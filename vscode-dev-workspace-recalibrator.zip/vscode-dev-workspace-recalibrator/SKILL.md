---
name: vscode-dev-workspace-recalibrator
description: Evaluate a VS Code web/dev workspace from a vscode.dev GitHub link or an already-open workspace, reconstruct the project's actual state and intent, detect stale or conflicting instructions, and recalibrate the execution instructions so the coding agent can complete the project with evidence-based verification.
---

# VS Code Dev Workspace Recalibrator

Use this skill when the user provides a `vscode.dev/github/...` link, a VS Code web workspace, or asks to inspect a development workspace and recalibrate the instructions needed to finish the project.

## Core objective

Move from **workspace as supplied** to **workspace as verified** and then to **execution-ready instructions**.

Never assume the existing instructions are current. Treat repository evidence as authoritative over stale prompts, TODO prose, generated status notes, or agent claims.

## Supported entry points

Accept:

- `https://vscode.dev/github/<owner>/<repo>/blob/<branch>`
- `https://vscode.dev/github/<owner>/<repo>`
- a VS Code web workspace already open to the repository
- a local/remote checkout supplied through the current environment

Normalize the input into:

- repository owner/name
- branch or commit when visible
- workspace root
- repository state actually accessible to the agent

If the link cannot be opened directly, continue using any accessible workspace/repository context. Do not invent repository contents.

## Operating contract

### 1. Establish the truth source

Inspect the repository before proposing changes.

First locate and read, when present:

- `AGENTS.md`
- `CLAUDE.md`
- `CODEX.md`
- `.github/copilot-instructions.md`
- `.cursor/rules/*`
- `.windsurf/*`
- `README*`
- project specifications, architecture documents, ADRs, design notes, and task/issue files
- root manifests and lockfiles
- CI/workflow definitions
- test configuration

Then inspect the source tree and identify the actual application entry points.

Prefer concrete executable evidence over narrative claims.

### 2. Build a workspace map

Produce an internal map containing:

- technology/runtime stack
- package/build tooling
- application entry points
- major modules/components
- configuration and environment boundaries
- persistence/data dependencies
- external integrations
- test/lint/type-check/build commands
- CI gates
- generated artifacts
- unresolved TODO/FIXME markers that appear project-relevant

Do not over-index on directory names. Confirm ownership through imports, references, manifests, and execution paths.

### 3. Reconstruct the intended outcome

Separate project intent into:

**Required behavior**
What the project is supposed to do, based on specifications, README, acceptance criteria, tests, and existing interfaces.

**Current behavior**
What the code actually does now.

**Required constraints**
Compatibility, framework conventions, data formats, security rules, deployment constraints, and repository-local instructions.

**Evidence gaps**
Places where intent or expected behavior cannot be established confidently.

When sources conflict, rank evidence approximately as:

1. Executable tests and compile/type-check/build behavior
2. explicit acceptance criteria or current task specification
3. current public interfaces/contracts used by the codebase
4. architecture/design documentation
5. README and developer documentation
6. comments/TODOs/status notes
7. assumptions from the agent or previous work

State uncertainty rather than silently resolving a conflict with a guess.

### 4. Evaluate completion

Classify relevant work into:

- **Verified complete** — implemented and supported by passing validation/evidence
- **Implemented but unverified** — code exists but required validation has not passed or cannot be run
- **Partially implemented** — meaningful implementation exists but acceptance criteria remain incomplete
- **Broken** — intended behavior exists but current validation exposes failure
- **Missing** — required capability is not implemented
- **Obsolete/stale** — instructions, scaffolding, or code no longer matches the current architecture
- **Blocked** — completion depends on unavailable credentials, services, decisions, or external inputs

Do not mark work complete because a file exists, a TODO disappeared, or an agent said it was finished.

### 5. Detect instruction drift

Look specifically for:

- instructions that describe files/directories that no longer exist
- duplicated or contradictory agent instructions
- commands that no longer work because tooling changed
- references to deprecated frameworks/APIs
- acceptance criteria no longer reflected in tests
- tests that encode obsolete behavior
- generated files being edited instead of their source
- configuration copied across environments incorrectly
- deployment assumptions inconsistent with the repository
- TODO lists that no longer match implementation
- instructions that cause the agent to redo completed work

When drift is detected, preserve still-valid constraints and rewrite only what has become stale.

### 6. Validate the project

Use the repository's own preferred commands when available.

Typical validation layers, in this order when applicable:

1. dependency/configuration integrity
2. formatting/lint
3. static analysis/type checking
4. focused/unit tests
5. integration tests
6. build/package
7. end-to-end/smoke tests
8. deployment-specific checks

Do not manufacture commands. Derive them from package scripts, Makefiles, task runners, CI workflows, or documented developer commands.

If a command cannot be run, record the exact reason and distinguish **unverified** from **failed**.

### 7. Trace requirements to evidence

For each substantive acceptance criterion, establish a trace:

`requirement -> implementation -> validation -> evidence`

A criterion is not verified when any link in that chain is missing.

Prefer concrete references such as:

- file/path
- symbol/function/component
- test name
- command and exit result
- CI workflow/job
- configuration key

### 8. Recalibrate the execution instructions

Produce a compact, ordered instruction set for the coding agent.

It must contain:

**Current state**
A factual snapshot of what is implemented and what remains.

**Do not redo**
Explicitly protect verified work from unnecessary rewrites.

**Remaining work**
Ordered by dependency, not by the order items appeared in old instructions.

**Implementation guidance**
Name the files/components and intended behavior without prescribing unnecessary rewrites.

**Validation**
Exact repository-native commands and expected evidence.

**Completion gates**
Objective conditions required before claiming completion.

**Blocked items**
External dependencies or missing decisions that prevent verification.

### 9. Execute, then reassess

When the surrounding task authorizes code changes, use the recalibrated instructions to implement the highest-priority remaining work.

After edits:

- inspect the diff
- rerun the narrowest relevant tests first
- rerun broader validation as needed
- check for accidental scope expansion
- update the requirement/evidence trace
- reassess whether remaining instructions are still correct

Do not stop at “code changed.” Stop at a verified completion state or an explicit, evidence-backed blocker.

## Safety and scope controls

- Never delete or overwrite project files merely to make validation pass.
- Never replace working architecture with a new stack without explicit evidence that the existing approach is invalid.
- Do not add dependencies when the current toolchain can satisfy the requirement without them.
- Do not expose or copy secrets, tokens, private keys, or environment credentials into reports or patches.
- Treat generated artifacts as outputs unless the repository explicitly treats them as source-controlled inputs.
- Preserve backward-compatible interfaces unless the task specification explicitly allows a breaking change.
- Keep changes scoped to the stated project objective and newly discovered dependencies necessary to complete it.

## Output format

When asked to **evaluate only**, return:

### Workspace diagnosis
Repository/branch, stack, current state, and significant constraints.

### Completion assessment
A concise table of relevant requirements with status and evidence.

### Instruction drift
Stale, conflicting, or misleading instructions found.

### Recalibrated execution instructions
A ready-to-use ordered instruction block for the coding agent.

### Validation gates
The exact checks required to declare completion.

### Blockers / evidence gaps
Only items that genuinely prevent verification or execution.

When asked to **evaluate and complete**, perform the same assessment first, then make the authorized changes and finish with:

### Completed work
What changed, with file/symbol references.

### Verification
Commands run, results, and any remaining unverified areas.

### Remaining work
Only genuinely incomplete or blocked items.

## Special handling for vscode.dev links

A `vscode.dev` URL is an entry point, not proof of repository state.

For URLs shaped like:

`https://vscode.dev/github/ashleybain-auto/Expanse-ConfigTool-Factory/blob/main`

parse the repository identity as `ashleybain-auto/Expanse-ConfigTool-Factory` and the base branch as `main`, but re-check the actual checked-out revision and workspace contents before drawing conclusions.

If the repository is private and the current environment lacks authenticated repository access, say so explicitly. Continue by evaluating whatever repository artifacts are available through the active workspace; otherwise return a **workspace access blocker** rather than fabricating findings.

## Recalibration principles

The skill's central rule is:

> **Do not optimize the instructions for what the project was supposed to be at the start. Optimize them for what the repository demonstrably needs now to satisfy the project's actual acceptance criteria.**

A good recalibration reduces ambiguity, preserves verified progress, exposes missing validation, and gives the coding agent a finite path to completion.

## Completion standard

The project is complete only when:

- required behavior is implemented
- repository-native validation passes at the appropriate level
- no critical acceptance criterion lacks evidence
- configuration/deployment behavior is consistent with the intended environment
- no known instruction drift would cause the next agent to regress or redo valid work
- the final diff is scoped and internally coherent

Never use a subjective percentage as the completion measure. Use evidence-backed states instead.
